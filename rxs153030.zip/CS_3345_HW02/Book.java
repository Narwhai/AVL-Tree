class Book 
{
	int id;

	Book(int d)
	{
		id = d;
	}
}